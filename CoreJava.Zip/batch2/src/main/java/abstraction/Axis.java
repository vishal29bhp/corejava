package abstraction;

class Axis extends Bank {
	int getRateOfInterest() {
		return 9;
	}
}