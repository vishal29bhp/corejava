package abstraction;

abstract class Bank {
	abstract int getRateOfInterest();
}