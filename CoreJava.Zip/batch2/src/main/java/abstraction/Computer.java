package abstraction;
public abstract class Computer implements Cloneable{
	
	public abstract String getRAM();
	public abstract String getHDD();
	public abstract String getCPU();
	
	@Override
	public String toString(){
		return "RAM= "+getRAM()+", HDD="+getHDD()+", CPU="+getCPU();
	}
	@Override
	public Object clone() {
		try{  
	        return super.clone();  
	    }catch(CloneNotSupportedException e){ 
	        return null; 
	    }
	}
	
}