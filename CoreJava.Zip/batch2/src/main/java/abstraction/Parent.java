package abstraction;
import abstractionwithinterface.Drawable;

abstract public class Parent extends ForParent implements Drawable{

}
