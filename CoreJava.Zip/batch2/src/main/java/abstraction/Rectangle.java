package abstraction;

class Rectangle extends Shape {
	void draw() {
		System.out.println("drawing rectangle");
	}
}