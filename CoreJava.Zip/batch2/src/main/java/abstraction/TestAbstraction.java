package abstraction;

class TestAbstraction {
	public static void main(String args[]) {
		Shape s = new Circle();
		s.draw();
	}
}