package aggregation;

public class Salary {
	public int basic;
	public int hra;
	public int variable;
	public int pfAmount;
	
	public Salary(int basic , int hra , int variable, int pf) {
		this.basic=basic;
		this.hra=hra;
		this.variable= variable;
		pfAmount=pf;
	}
}
