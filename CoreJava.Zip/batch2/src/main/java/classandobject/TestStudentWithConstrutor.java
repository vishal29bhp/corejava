package classandobject;


public class TestStudentWithConstrutor {
	
	
	static {
		System.out.println("TestStudentWithConstrutor");
	}

	@SuppressWarnings("rawtypes")
	public static void main(String[] args) {
		Student s1 = new Student(101, "Vishal");
		Student s2 = new Student(102, "Vimal");
		Student s3 = new Student(s1);
		Student s4 = new Student();
		
	    int student1Rolno=s1.displayInformation();
	    s2.displayInformation();
	    s3.displayInformation();
	    s4.displayInformation();
	    //System.out.println(Student.displayCounter());
	    
	    
	    //StudentV2 student = new StudentV2(12, "Vishal");
	    //StudentV2 student = new StudentV2();
	    //student.insertRecord(12, "Vishal");
	    //student.displayInformation();
	    //student.print();
	    
	}

}
