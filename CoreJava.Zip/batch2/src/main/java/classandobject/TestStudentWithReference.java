package classandobject;

public class TestStudentWithReference {

	public static void main(String[] args) {
		Student s1 = new Student();
		Student s2;
		s1.rollno = 10155;
		s1.name = "Vishal";
		/*
		 * s2.rollno = 102; s2.name = "Amit";
		 */
		s2 = s1;

		System.out.println(s1.rollno + " " + s1.name);
		System.out.println(s2.rollno + " " + s2.name);
	}
}
