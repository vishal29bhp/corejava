package collection;

import java.util.*;

class TestArrayList {
	public static void main(String args[]) {
		List genericList = new ArrayList();
		
		List<String> list = new ArrayList<String>();// Creating arraylist
		list.add("Ravi");// Adding object in arraylist
		list.add("Vijay");
		list.add("Ravi");
		list.add("Ajay");
		
		ArrayList<String> list2 = new ArrayList<String>();
		
		list2.add("Vishal");
		list2.add("Suresh");
		list2.add("SomeName");
		
		list.addAll(0,list2);
		
		ArrayList<Integer> list3 = new ArrayList<Integer>();
		list3.add(56);
		list3.add(new Integer(67));
		list3.add(54);
		
		genericList.addAll(list3);
		genericList.addAll(list2);
		genericList.addAll(list);
		
		list.add(0, "Kapil");
		
		// Getting Iterator
		Iterator<String> itr = list.iterator();
		// traversing elements of ArrayList object
		
		//list.add(0, "New Person");
		
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		
		System.out.println("---------------------");
		for (String name : list)
			System.out.println(name);
		
		
		System.out.println("---------------------");
		for(Object object: genericList) {
			if(object instanceof String) {
				System.out.println((String)object.toString());
			}
			else if(object instanceof Integer) {
				System.out.println(((Integer) object).intValue());
			}
		}
		System.out.println("---------------------");
	}
}
