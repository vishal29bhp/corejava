package collection;

import java.util.*;

class TestCollectionSort {
	public static void main(String args[]) {

		ArrayList<String> al = new ArrayList<String>();
		al.add("Virat");
		al.add("Sachin");
		al.add("Yuvraj");
		al.add("Mahendra");
		al.add("Kuldeep");
		al.add("Virendra");

		Collections.sort(al);
		Iterator<String> itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}