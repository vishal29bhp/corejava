package com.ethans.selenium.batch2.controlstatement;

public class DoWhileInfiniteExample {
	public static void main(String[] args) {
		do {
			System.out.println("infinitive do while loop");
		} while (true);
	}
}