package com.ethans.selenium.batch2.controlstatement;

public class ForExample {
	public static void main(String[] args) {
		/*
		 * int i = 10;
		 * 
		 * for (;;) { if (i >= 1) System.out.println(--i); }
		 */
		int j = 10;
		for (; j >= 1; --j) {
			System.out.println(j);
		}

	}
}