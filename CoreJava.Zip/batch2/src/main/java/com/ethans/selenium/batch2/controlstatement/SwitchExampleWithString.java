package com.ethans.selenium.batch2.controlstatement;

public class SwitchExampleWithString {
	public static void main(String[] args) {
		String str = " ";
		switch (str) {
		case "Before Java 6":
			System.out.println("Not Included only Integers");
			break;
		case "After Java 6":
			System.out.println("Included");
			break;
		case "":
			System.out.println("Included");
			break;
		default:
			System.out.println("Default");
		}
	}
}