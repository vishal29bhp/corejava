package exception;

class Parent {
	void msg() throws ArithmeticException {
		System.out.println("parent");
	}
}