package exception;

class TestFinallyBlock {
	
  /*1) exception does not occurs
    2) exception does occurs not handled
    3) exception does occurs and handled*/
	
	public static void main(String args[]) {
		try {
			int data = 25 / 5;
			System.out.println(data);
			System.exit(0);
		} catch (NullPointerException e) {
			System.out.println(e);
		}
		catch (ArithmeticException e) {
			System.out.println(e);
		} finally {
			System.out.println("finally block is always executed");
		}
		System.out.println("rest of the code...");
	}
}