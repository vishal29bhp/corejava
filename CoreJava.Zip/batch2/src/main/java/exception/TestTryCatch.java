package exception;

@SuppressWarnings("unused")
public class TestTryCatch {
	public static void main(String args[]) {
			try {
				int data = 50 / 0;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("After this no execution");
			
		System.out.println("rest of the code...");
	}
}