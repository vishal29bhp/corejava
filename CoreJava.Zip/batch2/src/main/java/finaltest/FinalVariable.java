package finaltest;

class FinalVariable {
	final int limit = 90;// final variable

	void run() {
		//limit = 400;
	}
}