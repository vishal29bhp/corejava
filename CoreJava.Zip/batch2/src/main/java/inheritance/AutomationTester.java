package inheritance;

public class AutomationTester extends Tester {

}
