package inheritance;

public class JavaProgrammer extends Programmer {

}
