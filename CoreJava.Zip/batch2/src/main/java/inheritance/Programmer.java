package inheritance;

class Programmer extends Employee {
	int bonus = 10000;
	static {
		System.out.println("Programmer Static Block");
	}

	public static void main(String args[]) {
		Programmer p = new Programmer();
	}
}