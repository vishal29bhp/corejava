package inheritance;

public class Tester extends Employee {
	int bonus = 20000;
	static {
		System.out.println("Tester Static Block");
	}
}
