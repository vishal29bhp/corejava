package multithreading;

class MyThreadCounterOne extends Thread {
	Counter t;

	MyThreadCounterOne(Counter t) {
		this.t = t;
	}

	public void run() {
		t.printCounter(5);
	}
}