package multithreading;

class MyThreadCounterTwo extends Thread {
	Counter t;

	MyThreadCounterTwo(Counter t) {
		this.t = t;
	}

	public void run() {
		t.printCounter(100);
	}
}