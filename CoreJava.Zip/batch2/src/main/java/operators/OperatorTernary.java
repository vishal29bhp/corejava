package operators;

public class OperatorTernary {
	
	float percent ;

	public static void main(String[] args) {
		int a = 2;
		int b = 5;
		int c = 7;
		int d = 8;
		//int min = (a < b) ? ((a == b) ? c : d) : b;//8
		int min = (a > b) ? c : d;
		System.out.println(min);
	}
}
