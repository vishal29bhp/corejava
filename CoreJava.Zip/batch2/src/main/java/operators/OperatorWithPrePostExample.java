package operators;

class OperatorWithPrePostExample {
	public static void main(String args[]) {
		int a = 10;
		int b = 10;
		System.out.println(a++ + ++a);// Any Guess?  22,
		System.out.println(b++ + b++);// Any Guess?  22,21,23
		//System.out.println(b);//12

	}
}