package polymorphism;

class AdderSameNoOfArg {
	static int add(int a, int b) {
		return a + b;
	}

	static double add(double a, double b, double c) {
		return a + b + c;
	}

	static String add(String a, String b) {
		return a + b;
	}
}