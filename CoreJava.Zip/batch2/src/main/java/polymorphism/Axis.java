package polymorphism;

class Axis extends Bank {
	public int getRateOfInterest() {
		return 9;
	}
	double getVariableRateOfInterest(double rate) {
		return rate;
	}
}