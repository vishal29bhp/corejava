package polymorphism;

class Bank {
   int getRateOfInterest() {
		return 0;
	}
	
   double getVariableRateOfInterest(double rate) {
		return rate;
	}
}