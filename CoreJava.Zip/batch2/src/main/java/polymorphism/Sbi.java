package polymorphism;

class Sbi extends Bank {
	int getRateOfInterest() {
		return 8;
	}
}