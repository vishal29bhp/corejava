package polymorphism;

class TestOverriding {
	public static void main(String args[]) {
		Bank s = new Sbi();
		Bank i = new Icici();
		Bank a = new Axis();
		Axis a2 = new Axis();
		Bank b = new Bank();
		System.out.println("SBI Rate of Interest: " + s.getRateOfInterest());
		System.out.println("ICICI Rate of Interest: " + i.getRateOfInterest());
		System.out.println("AXIS Rate of Interest: " + a.getRateOfInterest());
		System.out.println("Bank Rate of Interest: " + b.getRateOfInterest());
		System.out.println("Bank Varibale Rate of Interest: " + b.getVariableRateOfInterest(12.9));
		
		System.out.println("Axis Bank Varibale Rate of Interest: " + a2.getVariableRateOfInterest(13.4));

	}
}