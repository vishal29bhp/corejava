package reflectionapi;

import java.lang.reflect.InvocationTargetException;

import classandobject.Student;

public class ReflectionApiTest {

	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		Class clazz = Class.forName("classandobject.Student");
		System.out.println(clazz);
		Object student =  clazz.newInstance();
		

	}

}
