package test;

import java.util.StringTokenizer;

public class Simple extends Thread {
	public static void main(String args[]) {
		StringTokenizer st = new StringTokenizer("Get Entertained", "t");
		while (st.hasMoreTokens()) {
			System.out.print(st.nextToken());
		}
		int x,y;
		x = 5>>2;
		y = x>>>2;
		System.out.println(y);
	}
}