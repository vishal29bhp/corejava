package abstraction;

public class ForParent {

}
