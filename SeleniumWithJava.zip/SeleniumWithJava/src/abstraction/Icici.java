package abstraction;

class Icici extends Bank {
	int getRateOfInterest() {
		return 7;
	}
}