package abstraction;

public class TestAbstractionExample {
	public static void main(String[] args) {
		Bank s = new Sbi();
		Bank i = new Icici();
		Bank a = new Axis();
		System.out.println("SBI Rate of Interest: " + s.getRateOfInterest());
		System.out.println("ICICI Rate of Interest: " + i.getRateOfInterest());
		System.out.println("AXIS Rate of Interest: " + a.getRateOfInterest());
	}

}
