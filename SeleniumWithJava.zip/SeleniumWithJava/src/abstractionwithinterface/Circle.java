package abstractionwithinterface;

class Circle implements Drawable {
	public void draw() {
		System.out.println("drawing circle");
	}
	
	 public void msg() {
		System.out.println("Deafult of Circle");
	}
}