package abstractionwithinterface;

public interface Drawable {
	void draw();
	
	// Java 8 default method
	default void msg() {
		System.out.println("default method");
	}
	// Java 8 static method
	static int cube(int x) {
		return x * x * x;
	}
}