package abstractionwithinterface;

public interface TaggedInterface {
	
	//Serializable
	//Cloneable
	//
}
