package abstractionwithinterface;

class TestInterface {
	public static void main(String args[]) {
		Drawable d = new Circle();
		Drawable r = new Rectangle();
		d.draw();
		r.draw();
		d.msg();
		System.out.println(Drawable.cube(7));
	}
}