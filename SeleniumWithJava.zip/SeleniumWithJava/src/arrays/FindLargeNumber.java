package arrays;

import java.util.Scanner;

@SuppressWarnings("resource")
public class FindLargeNumber {

	public static void main(String[] args) {
		int large, size, i;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter Array Size : ");
		size = scan.nextInt();
		
		int arr[] = new int[size];

		System.out.print("Enter Array Elements : ");
		for (i = 0; i < size; i++) {
			arr[i] = scan.nextInt();
		}

		System.out.print("Searching for the Largest Number....\n\n");

		large = arr[0];

		for (i = 0; i < size; i++) {
			if (large < arr[i]) {
				large = arr[i];
			}

		}

		System.out.print("Largest Number = " + large);
	}

}
