package arrays;

class TestArray {
	public static void main(String args[]) {

		int a[] = new int[]{ 33, 3, 4, 5 };// declaration, instantiation and initialization

		for (int i = 0; i < a.length; i++)
			System.out.println(a[i]);
		
		for(int j:a) {
			System.out.println(j);
		}

	}
}