package arrays;

class TestArrayTwoDimension {
	public static void main(String args[]) {

		// declaring and initializing 2D array
		int arr[][] = { { 1, 2, 3 }, { 2, 4, 5 }, { 4, 4, 5 } };

		// printing 2D array
		/*for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print("arr[" + i + "][" + j + "]="+arr[i][j] + "\t");
			}
			System.out.println();
		}*/
		for(int arrOneD[]:arr) {
			for(int a:arrOneD) {
				System.out.print("arr[][]="+ a + "\t");
			}
			System.out.println();
		}

	}
}