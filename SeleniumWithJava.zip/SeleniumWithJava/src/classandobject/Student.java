package classandobject;

import java.util.Comparator;

public class Student implements Comparable {

	public int rollno;
	public String name;
	public int age;
	// String collegeName="IIM";
	static String collegeName = "IIM";
	static int counter = 1;

	void insertRecord(int r, String n) {
		rollno = r;
		name = n;
	}

	void displayInformation() {
		System.out.println(displayCounter() + " " + rollno + " " + name + "  " + collegeName);
		// System.out.println(displayCounter() +" "+rollno + " " + name+"
		// "+collegeName);
		// counter++;
	}

	static int displayCounter() {

		return counter++;

	}

	public Student() {
		// collegeName="IMS";
	}

	Student(int rlno) {
		rollno = rlno;
	}

	Student(int rlno, String studenName) {
		rollno = rlno;
		name = studenName;
	}

	public Student(int rlno, String studenName, int age) {
		rollno = rlno;
		name = studenName;
		this.age = age;
	}

	Student(Student student) {
		rollno = student.rollno;
		name = student.name;
	}

	static {
		// System.out.println("Static Block");
	}

	public int hashCode() {
		// System.out.println("In hashcode");
		int hashcode = 0;

		hashcode = 101 * (int) Math.random();
		hashcode += "vishal".hashCode();
		hashcode += 24;

		return hashcode;
	}

	public boolean equals(Object obj) {
		// System.out.println("In equals");
		if (obj instanceof Student) {
			Student student = (Student) obj;
			return (student.rollno == this.rollno && student.name.equals(this.name) && student.age == this.age);
		} else {
			return false;
		}
	}

	@Override
	public int compareTo(Object o) {
		Student st = (Student) o;
		if (age == st.age)
			return 0;
		else if (age > st.age)
			return 1;
		else
			return -1;
	}

	public String toString() {
		return this.rollno + " " + this.name + " " + this.age;
	}

}
