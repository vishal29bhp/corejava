package classandobject;

class TestStudent {
	public static void main(String args[]) {
		Student s1 = new Student();
		System.out.println(s1.rollno);
		System.out.println(s1.name);
		s1.rollno=12;
		s1.name="Name";
		System.out.println(s1.rollno);
		System.out.println(s1.name);
	}
}