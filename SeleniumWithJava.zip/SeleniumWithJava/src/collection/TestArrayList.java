package collection;

import java.util.*;

class TestArrayList {
	public static void main(String args[]) {
		List<String> list = new ArrayList<String>();// Creating arraylist
		list.add("Ravi");// Adding object in arraylist
		list.add("Vijay");
		list.add("Ravi");
		list.add("Ajay");
		
		ArrayList<String> list2 = new ArrayList<String>();
		
		list2.add("Vishal");
		list2.add("Suresh");
		list2.add("SomeName");
		
		list.addAll(0,list2);
		
		list.add(0, "Kapil");
		
		// Getting Iterator
		Iterator<String> itr = list.iterator();
		// traversing elements of ArrayList object
		
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("---------------------");
		for (String name : list)
			System.out.println(name);
	}
}
