package collection;

import java.util.ArrayList;
import java.util.Collections;

import classandobject.NameComparator;
import classandobject.RollNoComparator;
import classandobject.Student;

public class TestCollectionSortStudent {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

		Student s1 = new Student(101, "Amit", 23);
		Student s2 = new Student(102, "Ravi", 21);
		Student s3 = new Student(103, "Hanumant", 25);
		Student s4 = new Student(104, "Vishal", 22);

		ArrayList<Student> al = new ArrayList<Student>();
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);

		Collections.sort(al);

		for (Student student : al)
			System.out.println(student);

		System.out.println("--------------------------------");

		Collections.sort(al, new NameComparator());

		for (Student student : al)
			System.out.println(student);

		System.out.println("--------------------------------");
		
		Collections.sort(al, new RollNoComparator());

		for (Student student : al)
			System.out.println(student);
	}
}
