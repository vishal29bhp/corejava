package collection;

import java.util.*;

class TestHashSet {
	public static void main(String args[]) {
		HashSet<String> list = new HashSet<String>();// Creating HashSet
		list.add("Ravi");// Adding object in HashSet
		list.add("Vijay");
		list.add("Ravi");
		list.add("Ajay");
		list.add("Bhushan");
		// Getting Iterator
		Iterator itr = list.iterator();
		// traversing elements of HashSet object
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("-----------------------");
		for (String name : list)
			System.out.println(name);
	}
}
