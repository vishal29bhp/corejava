package collection;

import java.util.*;

class TestLinkedHashSet {
	public static void main(String args[]) {
		LinkedHashSet<String> list = new LinkedHashSet<String>();// Creating LinkedHashSet
		list.add("Ravi");// Adding object in LinkedHashSet
		list.add("Vijay");
		list.add("Ravi");
		list.add("Ajay");
		for (String name : list)
			System.out.println(name);
	}
}
