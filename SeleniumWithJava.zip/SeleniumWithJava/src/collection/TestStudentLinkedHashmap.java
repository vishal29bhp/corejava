package collection;

import java.util.*;

import classandobject.Student;

class TestStudentLinkedHashmap {
	public static void main(String args[]) {
		
		Student s1 = new Student(101, "Amit", 23);
		Student s2 = new Student(101, "Amit", 23);
		Student s5 = new Student(104, "Vishal", 28);
		Student s3 = new Student(103, "Hanumant", 25);
		Student s4 = new Student(103, "Hanumant", 25);
		
		LinkedHashMap<Integer, Student> hm = new LinkedHashMap<Integer, Student>();
		
		hm.put(1, s1);//what happens if the key is same 
		hm.put(2, s2);
		hm.put(3, s3);
		hm.put(4, s4);
		hm.put(5, s5);
		
		for (Map.Entry<Integer, Student> m : hm.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}
}