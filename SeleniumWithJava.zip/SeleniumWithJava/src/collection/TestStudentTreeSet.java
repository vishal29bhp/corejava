package collection;

import java.util.*;
import classandobject.*;

public class TestStudentTreeSet {
	public static void main(String args[]) {
		// Creating user-defined class objects
		Student s3 = new Student(103, "Hanumant", 25);
		Student s4 = new Student(103, "Hanumant", 25);
		Student s1 = new Student(101, "Amit", 23);
		Student s2 = new Student(101, "Amit", 23);
		// creating LinkedHashSet
		TreeSet<Student> al = new TreeSet<Student>();
		al.add(s1);// adding Student class object
		al.add(s2);
		al.add(s3);
		al.add(s4);
		// Getting Iterator
		Iterator itr = al.iterator();
		// traversing elements of LinkedHashSet object
		while (itr.hasNext()) {
			Student st = (Student) itr.next();
			System.out.println(st.rollno + " " + st.name + " " + st.age);
		}
	}
	
}