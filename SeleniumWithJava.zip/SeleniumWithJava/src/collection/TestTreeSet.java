package collection;

import java.util.*;

class TestTreeSet {
	public static void main(String args[]) {
		TreeSet<String> list = new TreeSet<String>();// Creating TreeSet
		list.add("Ravi");// Adding object in TreeSet
		list.add("Vijay");
		list.add("Ravi");
		list.add("Ajay");
		// Getting Iterator
		Iterator itr = list.descendingIterator();
		// traversing elements of TreeSet object
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("-----------------------");
		for (String name : list)
			System.out.println(name);
	}
}
