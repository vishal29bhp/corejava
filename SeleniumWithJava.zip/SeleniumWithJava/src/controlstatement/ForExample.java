package controlstatement;

public class ForExample {
	public static void main(String[] args) {
		for (int i = 10; i >= 1; ) {
			System.out.println(--i);
		}
	}
}