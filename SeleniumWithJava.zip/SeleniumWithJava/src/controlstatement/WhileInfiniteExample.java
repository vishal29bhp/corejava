package controlstatement;

public class WhileInfiniteExample {
	public static void main(String[] args) {
		while (true) {
			System.out.println("infinitive while loop");
		}
	}
}