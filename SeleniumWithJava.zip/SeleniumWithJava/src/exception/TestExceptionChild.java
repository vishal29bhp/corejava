package exception;

class TestExceptionChild extends Parent {
	//try with unchecked exception
	//if super class method throws exception ,
	 //subclass should not throws parent exception
	// but can throws child exception , same exception and even no exception
	void msg() {
		super.msg();
		throw new ArithmeticException();
		//int data = 10 / 2;
		//System.out.println("TestExceptionChild");
		//throw new ArithmeticException();
		
	}

	public static void main(String args[]) {
		Parent p = new TestExceptionChild();
		try {
			p.msg();
		} catch (ArithmeticException e) {
			System.out.println("TestExceptionChild in Main");
		}
	}
}