package exception;

import java.io.IOException;

class TestExceptionPropagationChecked{  
  void m() throws IOException{  
    throw new java.io.IOException("device error");//checked exception  
  }  
  void n() throws IOException{  
    m();  
  }  
  void p(){  
   try{  
    n();  
   }catch(Exception e){System.out.println("exception handeled"+e.getMessage());}  
  }  
  public static void main(String args[]){  
   TestExceptionPropagationChecked obj=new TestExceptionPropagationChecked();  
   obj.p();  
   System.out.println("normal flow");  
  }  
}  