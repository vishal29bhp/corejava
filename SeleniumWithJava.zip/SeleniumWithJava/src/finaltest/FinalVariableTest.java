package finaltest;

public class FinalVariableTest {

	public static void main(String[] args) {
		FinalVariable fv = new FinalVariable();
		fv.run();
	}

}
