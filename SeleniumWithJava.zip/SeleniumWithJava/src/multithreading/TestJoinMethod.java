package multithreading;

class TestJoinMethod extends Thread {
	
	String threadName;
	public TestJoinMethod(String threadName) {
		this.threadName=threadName;
	}

	public void run() {
		for (int i = 1; i <= 5; i++) {
			try {
				Thread.sleep(500);
				System.out.println(this.threadName+" Runnning");
			} catch (Exception e) {
				System.out.println(e);
			}
			System.out.println(" Count "+i);
		}
	}

	public static void main(String args[]) {
		TestJoinMethod t1 = new TestJoinMethod("Thread 1---");
		TestJoinMethod t2 = new TestJoinMethod("Thread 2---");
		TestJoinMethod t3 = new TestJoinMethod("Thread 3---");
		t1.start();
		t2.start();
		t3.start();
		try {
			t1.join();
		} catch (Exception e) {
			System.out.println(e);
		}

		
	}
}