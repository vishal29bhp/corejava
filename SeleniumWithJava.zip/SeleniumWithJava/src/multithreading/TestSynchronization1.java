package multithreading;

class TestSynchronization1 {
	public static void main(String args[]) {
		Counter obj = new Counter();// only one object
		MyThreadCounterOne t1 = new MyThreadCounterOne(obj);
		MyThreadCounterTwo t2 = new MyThreadCounterTwo(obj);
		t1.start();
		t2.start();
	}
}