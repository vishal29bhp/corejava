package operators;

public class OperatorTernary {

	public static void main(String[] args) {
		int a = 2;
		int b = 5;
		int c = 7;
		int d = 8;
		int min = (a < b) ? ((a == b) ? c : d) : b;
		System.out.println(min);
	}
}
