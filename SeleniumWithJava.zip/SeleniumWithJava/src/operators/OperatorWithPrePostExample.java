package operators;

class OperatorWithPrePostExample {
	public static void main(String args[]) {
		int a = 10;
		int b = 10;
		System.out.println(a++ + ++a);// Any Guess?
		System.out.println(b++ + b++);// Any Guess?
		System.out.println(b);

	}
}