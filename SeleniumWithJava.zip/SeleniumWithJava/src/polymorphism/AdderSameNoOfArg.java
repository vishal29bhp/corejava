package polymorphism;

class AdderSameNoOfArg {
	static int add(int a, int b) {
		return a + b;
	}

	static double add(double a, double b) {
		return a + b;
	}
}