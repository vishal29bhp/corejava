package polymorphism;

class Axis extends Bank {
	int getRateOfInterest() {
		return 9;
	}
}