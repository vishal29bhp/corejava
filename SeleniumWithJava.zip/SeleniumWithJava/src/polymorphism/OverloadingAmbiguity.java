package polymorphism;

class OverloadingAmbiguity {
	void sum(int a, long b) {
		System.out.println("int arg method invoked");
	}

	void sum(long a, int b) {
		System.out.println("long arg method invoked");
	}

	public static void main(String args[]) {
		OverloadingAmbiguity obj = new OverloadingAmbiguity();
		obj.sum(20, 20);// now second int literal will be promoted to long
		obj.sum(20, 20);

	}
}