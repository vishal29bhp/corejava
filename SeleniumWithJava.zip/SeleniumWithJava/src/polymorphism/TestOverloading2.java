package polymorphism;

class TestOverloading2 {
	public static void main(String[] args) {
		System.out.println(AdderSameNoOfArg.add(11, 11));
		System.out.println(AdderSameNoOfArg.add(12.3, 12.6));
	}
}