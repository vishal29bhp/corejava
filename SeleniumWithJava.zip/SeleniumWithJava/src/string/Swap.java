package string;

class Swap {
	 String a = "Vishal";
	 String b = "Chawre";
	
	public static void main(String args[]) {
		
		Swap swap = new Swap();
			
		System.out.println("Strings before swap: a = " + swap.a + " and b = " + swap.b);
		swap(swap);
		System.out.println("Strings after swap: a = " + swap.a + " and b = " + swap.b);

	}

	public static void swap(Swap swap) {
		
		swap.a = swap.a + swap.b;
		swap.b = swap.a.substring(0, swap.a.length() - swap.b.length());
		swap.a = swap.a.substring(swap.b.length());
		
		/*String tmp = a;
		a=b;
		b=tmp;*/
	}
}