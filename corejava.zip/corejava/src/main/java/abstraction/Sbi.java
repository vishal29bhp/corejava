package abstraction;

class Sbi extends Bank {
	int getRateOfInterest() {
		return 8;
	}
}