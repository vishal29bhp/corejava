package aggregation;

public class Employee {
	int id;
	String name;
	Address address;
	Salary salary;
	
	public Employee() {
		
	}

	public Employee(int id, String name, Address address) {
		this.id = id;
		this.name = name;
		this.address = address;
	}

	void display() {
		System.out.println(id + " " + name);
		System.out.println(address.city + " " + address.state + " " + address.country);
		System.out.println(salary.basic + " " + salary.hra + " " + salary.variable+" "+salary.pfAmount);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Salary getSalary() {
		return salary;
	}

	public void setSalary(Salary salary) {
		this.salary = salary;
	}

	public static void main(String[] args) {
		//Address address1 = new Address("Pune", "MH", "india");
		//Address address2 = new Address("Mumbai", "MH", "india");

		//Employee e = new Employee(111, "Vishal", address1);
		//Employee e2 = new Employee(112, "Amit", address2);
		Employee emp = new Employee();
		emp.setId(51414);
		emp.setName("Vishal");
		Address add = new Address("Pune", "MH", "india");
		emp.setAddress(add);
		Salary sal = new Salary(1000, 1200, 300, 120);
		emp.setSalary(sal);

		emp.display();
	}
}