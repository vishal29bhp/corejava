package classandobject;

public class Student implements Comparable {

	public int rollno;
	public String name;
	public int age;
	// String collegeName="IIM";
	static String collegeName = "IIM";
	static int counter = 1;

	Object object;

	void insertRecord(int r, String n) {
		rollno = r;
		name = n;
	}

	int displayInformation() {
		System.out.println(displayCounter() + " " + rollno + " " + name + "  " + collegeName);
		// System.out.println(displayCounter() +" "+rollno + " " + name+"
		// "+collegeName);
		// counter++;
		return rollno;
	}

	static int displayCounter() {

		return counter++;

	}

	public Student() {
		// collegeName="IMS";
	}

	Student(int rlno) {
		rollno = rlno;
	}

	Student(StudentV2 student) {
		this.rollno = student.rollno;
	}

	Student(int rlno, String studenName) {
		rollno = rlno;
		name = studenName;
	}

	public Student(int rlno, String studenName, int age) {
		rollno = rlno;
		name = studenName;
		this.age = age;
	}

	Student(Student student) {
		rollno = student.rollno;
		name = student.name;
	}

	int i;
	{
		System.out.println("Valid Construct");
		i = 90;
	}
	static {
		System.out.println("Static Block");
	}

	public int hashCode() { // System.out.println("In hashcode");
		int hashcode = 0;

		hashcode = rollno * (int) Math.random();
		hashcode += name.hashCode();
		hashcode += age;

		return hashcode;
	}

	public boolean equals(Object obj) { // System.out.println("In equals");
		/*
		 * if (obj instanceof Student) { Student student = (Student) obj; return
		 * (student.rollno == this.rollno && student.name.equals(this.name) &&
		 * student.age == this.age); } else { return false; }
		 */
		return true;
	}

	public int compareTo(Object o) {
		Student st = (Student) o;
		if (age == st.age)
			return 0;
		else if (age > st.age)
			return 1;
		else
			return -1;
	}

	public String toString() {
		return this.rollno + " " + this.name + " " + this.age;
	}

}
