package classandobject;

import java.util.Set;

class StudentV2 {
	int rollno;
	String name;
	String collegeName="IIM";
	//static String collegeName="IIM";
	static int counter=1;
    
	void insertRecord(int rollno, String name) {
		this.rollno = rollno;
		this.name = name;
		
	}

	void displayInformation() {
		System.out.println(counter +" "+rollno + " " + name+"  "+collegeName);
		//System.out.println(displayCounter() +" "+rollno + " " + name+"  "+collegeName);
		counter++;
	}
	
	static int displayCounter() {
		return counter++;
	}
	
	void printThis(StudentV2 student) {
		System.out.println(StudentV2.counter +" "+student.rollno + " " + student.name+"  "+student.collegeName);
	}
	
	void print() {
		System.out.println(StudentV2.counter +" "+this.rollno + " " + this.name+"  "+this.collegeName);
		printThis(this);
	    this.displayInformation();
	}
	
	public StudentV2 returnStudent() {
		return this;
	}

	StudentV2() {
		//this();
		this(5,"Jai");
		System.out.println("Student V2 Default");
		Student oldStudent = new Student(this);
		
	}

	StudentV2(int rollno) {
		rollno = rollno;
		//this();
	}

	StudentV2(int rollno, String name) {
		//this();
		this.rollno = rollno;
		this.name = name;
	}
	
	StudentV2(StudentV2 student){
		this();
		this.rollno=student.rollno;
		this.name=student.name;
	}

}
