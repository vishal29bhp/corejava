package classandobject;

public class TestStaticVariable {

	public static void main(String[] args) {
		/*System.out.println(Student.counter);
		Student s1 = new Student();
		System.out.println(Student.counter);
		Student.displayCounter();
		Student s2 = s1;
		s1.insertRecord(1001, "Vishal");
		s2.rollno=1002;
		s2.name= "New Student";
		
		Student s3 = new Student(1003, "One More Student");
		Student s4 = new Student(1004,"Another Student");
		s1.displayInformation();
		s2.displayInformation();
		s3.displayInformation();
		s4.displayInformation();*/
		//System.out.println(s1.displayCounter());
		
		StudentV2 s1v2 = new StudentV2();
		StudentV2 s2v2 = s1v2.returnStudent();
		//s1v2.insertRecord(1005, "This Student");
		s1v2.print();

	}

}
