package classandobject;

public class TestStudentWithMethod {

	public static void main(String[] args) {
		Student s1 = new Student();
		Student s2 = new Student();
		s1.insertRecord(111, "Vishal");
		s2.insertRecord(222, "Amit");
		s1.displayInformation();
		s2.displayInformation();
	}

}
