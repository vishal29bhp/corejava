package collection;

import java.util.*;

class TestHashSet {
	public static void main(String args[]) {
		HashSet<String> set = new HashSet<String>();
		//HashSet<Student> set = new HashSet<Student>();// Creating HashSet
		//set.add(new Student());
		set.add("Ravi");// Adding object in HashSet
		set.add("Vijay");
		set.add("Ravi");
		set.add("Ravi");
		set.add("Ravi");
		set.add("Ravi");
		set.add("Ajay");
		set.add("Bhushan");
		// Getting Iterator
		Iterator<String> itr = set.iterator();
		// traversing elements of HashSet object
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		/*System.out.println("-----------------------");
		for (String name : set)
			System.out.println(name);*/
	}
}
