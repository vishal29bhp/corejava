package collection;

import java.util.*;

class TestHashmap {
	public static void main(String args[]) {
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		hm.put(101, "Vijay");
		hm.put(102, "Rahul");
		hm.put(100, "Amit");
		
		for (Map.Entry<Integer, String> m : hm.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
		
		System.out.println("-------------------------------------");
		
		for (Integer key : hm.keySet()) {
			System.out.println(key + " " + hm.get(key));
		}
		
		System.out.println("-------------------------------------");
		
		for (String value : hm.values()) {
			System.out.println(" " + value);
		}
		
	}
}