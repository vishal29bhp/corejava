package collection;

import java.util.*;

class TestLinkedHashSet {
	public static void main(String args[]) {
		LinkedHashSet set = new LinkedHashSet();// Creating LinkedHashSet
		set.add("Ravi");// Adding object in LinkedHashSet
		set.add("Vijay");
		set.add("Ravi");
		set.add("Ajay");
		set.add("30.5");
		set.add(30.5);
		for (Object name : set)
			System.out.println(name);
	}
}
