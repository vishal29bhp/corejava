package collection;

import java.util.*;

class TestLinkedHashmap {
	public static void main(String args[]) {
		LinkedHashMap<Integer, String> hm = new LinkedHashMap<Integer, String>();
		hm.put(100, "Amit");
		hm.put(102, "Rahul");
		hm.put(101, "Vijay");
		for (Map.Entry<Integer, String> m : hm.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}
}