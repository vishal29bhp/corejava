package collection;

import java.util.*;
import classandobject.*;

public class TestStudentLinkedList {
	public static void main(String args[]) {
		// Creating user-defined class objects
		Student s1 = new Student(101, "Amit", 23);
		Student s2 = new Student(102, "Ravi", 21);
		Student s3 = new Student(103, "Hanumant", 25);
		Student s4 = new Student(104, "Vishal", 21);
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		// creating arraylist
		LinkedList<Student> al = new LinkedList<Student>();
		al.add(s1);// adding Student class object
		al.add(s2);
		al.add(s3);
		// Getting Iterator
		Iterator itr = al.iterator();
		// traversing elements of ArrayList object
		while (itr.hasNext()) {
			Student st = (Student) itr.next();
			System.out.println(st.rollno + " " + st.name + " " + st.age);
		}
		
		al.add(0, s4);
		
		System.out.println("----------After Adding Vishal------------");
		
		itr = al.iterator();
		
		while (itr.hasNext()) {
			Student st = (Student) itr.next();
			System.out.println(st.rollno + " " + st.name + " " + st.age);
		}
	}
}