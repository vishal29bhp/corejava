package collection;

import java.util.*;

import classandobject.Student;

class TestStudentTreeMap {
	public static void main(String args[]) {
		
		Student s1 = new Student(101, "Amit", 23);
		Student s2 = new Student(101, "Amit", 23);
		Student s5 = new Student(104, "Vishal", 28);
		Student s3 = new Student(103, "Hanumant", 25);
		Student s4 = new Student(103, "Hanumant", 25);
		
		TreeMap<Integer, Student> hm = new TreeMap<Integer, Student>();
		
		hm.put(s1.rollno, s1);
		hm.put(s5.rollno, s5);
		hm.put(s2.rollno, s2);
		hm.put(s4.rollno, s4);
		hm.put(s3.rollno, s3);
		
		
		for (Map.Entry<Integer, Student> m : hm.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}
}