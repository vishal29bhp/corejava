package controlstatement;

public class DoWhileExample {
	public static void main(String[] args) {
		int i = 11;
		do {
			System.out.println(i);
			System.out.println(i++);
		} while (i <= 10);
	}
}