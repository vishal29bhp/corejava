package controlstatement;

public class ForEachExample {
	public static void main(String[] args) {
		int arr[] = { 12, 23, 44, 56, 78 };
		int count = 0;
		for (int element : arr) {
			if (count <= 3) {
				System.out.println(element);
			}
			else
				break;
			count++;
		}
	}
}