package controlstatement;

public class ForInfiniteExample {
	public static void main(String[] args) {
		for (;;) {
			System.out.println("infinitive loop");
		}
	}
}