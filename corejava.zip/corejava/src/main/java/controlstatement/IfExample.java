package controlstatement;

public class IfExample {
	public static void main(String[] args) {
		Integer age = 20;
		if (age < 18) {
			System.out.print("Age is less than 18");
		} else if (age > 18) {
			System.out.print("Age is > than 18");
		} else {
			System.out.print("Default Age");
		}
	}
}