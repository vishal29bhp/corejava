package exception;

class Parent {
	void msg() throws ArithmeticException,Exception {
		System.out.println("parent");
	}
}