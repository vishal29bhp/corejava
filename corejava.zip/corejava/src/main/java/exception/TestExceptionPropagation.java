package exception;

class TestExceptionPropagation {
	void m() {
		int data = 50 / 0;
	}

	void n() {
		m();
	}

	void p() {
		n();

	}

	public static void main(String args[]) {
		TestExceptionPropagation obj = new TestExceptionPropagation();
		obj.p();
		System.out.println("normal flow...");
	}
}