package exception;

import java.io.IOException;

class TestExceptionPropagationChecked {
	void m() throws IOException  {
		
		System.out.println("Statement 1");
		System.out.println("Statement 2");
		
		throw new java.io.IOException("device error");// checked exception
	}

	void n() throws IOException  {
		m();
	}

	void p() throws IOException {
			n();
	}

	public static void main(String args[]) {
		TestExceptionPropagationChecked obj = new TestExceptionPropagationChecked();
		try {
			obj.p();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("normal flow");
	}
}