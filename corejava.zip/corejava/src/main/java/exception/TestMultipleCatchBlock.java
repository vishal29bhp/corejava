package exception;

public class TestMultipleCatchBlock {
	public static void main(String args[]) {
		try {
			int a[] = new int[5];
			a[6] = 30 / 0;

		} catch (ArrayIndexOutOfBoundsException e) {

			System.out.println("ArrayIndexOutOfBoundsException");
		} catch (ArithmeticException e) {

			System.out.println("ArithmeticException");
		} catch (Exception e) {
			// change the order of this catch block at first
			System.out.println("Exception");
		}

		System.out.println("rest of the code...");
	}
}