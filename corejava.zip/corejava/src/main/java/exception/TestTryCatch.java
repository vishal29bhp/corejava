package exception;

@SuppressWarnings("unused")
public class TestTryCatch {
	public static void main(String args[]) {
		int a = 10, b = 20, c , d;
		// try {
		int data = 50 / 0;
		c = a + b;
		// } catch (Throwable e) {
		// TODO Auto-generated catch block
		// e.printStackTrace();
		// c = a+b;
		// }
		System.out.println("After this no execution");

		System.out.println("rest of the code...");
	}
}