package inheritance;

class Employee {
	float salary = 40000;
	static {
		System.out.println("Employee Static Block");
	}
}