package inheritance;

public class EmployeeTest {

	public static void main(String[] args) {
			Programmer p = new Programmer();
		    Tester t = new Tester();
	}

}
