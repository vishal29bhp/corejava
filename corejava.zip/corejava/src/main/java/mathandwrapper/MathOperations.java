package mathandwrapper;

public class MathOperations {

	public static void main(String[] args) {

		System.out.println(Math.min(30, 34));
		System.out.println(Math.max(30, 34));
		System.out.println(Math.round(34.48));
		System.out.println(Math.abs(34.76));
		int i = 0;
		while (i < 10) {
			System.out.println((int)(Math.random() * 100));
			i++;
		}

	}

}
