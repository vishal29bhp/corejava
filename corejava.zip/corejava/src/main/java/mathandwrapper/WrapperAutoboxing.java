package mathandwrapper;

public class WrapperAutoboxing {
	public static void main(String args[]) {
		int a = 20;
		Integer i = Integer.valueOf(a);// converting int into Integer
		Integer j = a;// autoboxing, now compiler will write Integer.valueOf(a) internally
        char c ='A';
        j=(int) c;
		System.out.println(a +" " + i + " " + j);
		float value = 45.67f;
		Float floatObj = value;
		
		System.out.println(floatObj);
		
	}
}