package polymorphism;

class Icici extends Bank {
	int getRateOfInterest() {
		return 7;
	}
}