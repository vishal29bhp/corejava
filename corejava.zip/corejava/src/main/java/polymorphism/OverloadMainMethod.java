package polymorphism;

public class OverloadMainMethod {
	
	static{
		System.out.println("Static Block First");
		OverloadMainMethod omm2 = new OverloadMainMethod();
	}

	public static void main(String[] args) {
		System.out.println("Original Main Method");
		main("Call It");
		main(6);
		//main(new Integer(6));
		OverloadMainMethod omm = new OverloadMainMethod();

	}
	public static void main(String args) {
		System.out.println("Overloaded String Main Method");
	}
	public void main(Integer args) {
		System.out.println("Overloaded Wrapper Main Method");
		main(8);
	}
	public static void main(int args) {
		System.out.println("Overloaded Primitive Main Method");
	}

}
