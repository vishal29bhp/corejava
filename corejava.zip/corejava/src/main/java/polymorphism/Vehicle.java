package polymorphism;

class Vehicle {
	void run() {
		System.out.println("Vehicle is running");
	}
}