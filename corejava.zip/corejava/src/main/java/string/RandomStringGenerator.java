package string;

class RandomStringGenerator {
	public static void main(String args[]) throws InterruptedException {
       System.out.println(getRandomString()+" X "+getRandomString());
       Thread.sleep(500);
       System.out.println(getRandomString()+" X "+getRandomString());
       Thread.sleep(500);
       System.out.println(getRandomString()+" X "+getRandomString());
       Thread.sleep(500);
       System.out.println(getRandomString()+" X "+getRandomString());
       Thread.sleep(500);
       System.out.println(getRandomString()+" X "+getRandomString());
   
	}

	static String getRandomString() {
		int r = (int) (Math.random() * 10.45);
		String name = new String[] { "Mandar Mahajan",
				                     "Ram Mahajan",
				                     "Aziz Merchant", 
				                     "Jasmin Pandya",
				                     "Shrikant Bodhale",
				                     "Minoo Ichaporia",
				                     "Satvashil Shinde",
				                     "Vishal Chawre",
				                     "Subrat Barick",
				                     "Sandeep Maloo"}[r];
		return name;
	}
}