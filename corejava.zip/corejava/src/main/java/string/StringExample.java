package string;

class StringExample {
	public static void main(String args[]) {

		String s1 = "java";// creating string by java string literal
		char ch[] = { 's', 't', 'r', 'i', 'n', 'g', 's' };
		String s2 = new String(ch);// converting char array to string
		String s3 = new String("example");// creating java string by new keyword
		String s4 = "java";
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
        //5030Vishal4040
		//charcharVishalcharchar
		//80Vishal80
		//80Vishal4040
		String s = 50 + 30 + "Vishal" + 40 + 40;// After first String literal + operator treats every thing String
		System.out.println(s);

		s1 = "Vishal ";
		s2 = "Chawre";
		s3 = s1.concat(s2);
		System.out.println(s3);

		System.out.println(s3.substring(6));
		System.out.println(s3.substring(0, 6));

		System.out.println(s3.toUpperCase());
		System.out.println(s3.toLowerCase());

		int a = 10;
		String s5 = String.valueOf(a);
		System.out.println(s5 + 10);
		System.out.println(10 + 20 + s5);

		String s6 = "Java is a programming language. Java is a platform";
		String replaceString = s6.replaceAll("Java", "Kava");
		System.out.println(replaceString);
	}
}