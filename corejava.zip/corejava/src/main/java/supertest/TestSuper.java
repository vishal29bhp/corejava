package supertest;

class TestSuper {
	public static void main(String[] args) {
		Emp e1 = new Emp(1, "Jai", 45000f);
		e1.display();
	}
}