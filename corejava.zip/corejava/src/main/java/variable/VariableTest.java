package variable;

public class VariableTest {
	
	int sum2;//instance variable //0
	static int sum3;//static instance variable

	public static void main(String[] args) {
		int sum=10;//local variable //no initialization
		char character='A';
		boolean boolVar=true;
		float floatVar=12.3f;
		double doubleVar=13.5667d;
		byte bateVar=12;
		short shortVar=34;
		long longVar=56l;
		
		
        System.out.println("Static Variable"+VariableTest.sum3);
        //System.out.println("Static Variable"+sum2);
        System.out.println("Local Variable"+sum);
	}

}
