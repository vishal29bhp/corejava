package com.ethans.automation.corejava.abstraction;

public class AbstractionTest {

	public static void main(String[] args) {
		
		Developer dev = new Developer();
		dev.showDetails();
	}

}
