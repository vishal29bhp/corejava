package com.ethans.automation.corejava.abstraction;

public abstract class Computer implements Cloneable{

	abstract String getHDD();

	abstract String getRAM();

	abstract String getROM();

	public String toString() {
		return getHDD() + "::" + getRAM() + "::" + getROM();
	}
	
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}

}
