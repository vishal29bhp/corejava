package com.ethans.automation.corejava.abstraction;

public class ComputerFactory {
		
	public static Computer getComputer(String type,String hdd,
			                        String ram, String rom,String network) {
		
		if(type.equalsIgnoreCase("server")) {
			return new Server(hdd,ram,rom);
		}
		else if (type.equalsIgnoreCase("pc")) {
			return new PersonalComputer(hdd,ram,rom);
		}
		else if (type.equalsIgnoreCase("mobile")) {
			return new Mobile(hdd,ram,rom,network);
		}
		return null;
	}

}
