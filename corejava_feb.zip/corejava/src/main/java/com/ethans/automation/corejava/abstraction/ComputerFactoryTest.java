package com.ethans.automation.corejava.abstraction;

public class ComputerFactoryTest {
	
	public static void main(String[] args) throws CloneNotSupportedException {
		
		Computer server = ComputerFactory.getComputer("SERVER", "4TB", "64GB", "4TB",null);
		System.out.println("Server Details-"+server);
		Computer pc = ComputerFactory.getComputer("PC", "64GB", "16GB", "64GB",null);
		System.out.println("PC Details-"+pc);
		Computer mobile = ComputerFactory.getComputer("MOBILE", "16GB", "8GB", "16GB","4G");
		System.out.println("Mobile Details-"+mobile);
		
		Computer mobile2 = (Computer) mobile.clone();
		System.out.println("Mobile2 Details-"+mobile2);
		
	}

}
