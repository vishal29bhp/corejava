package com.ethans.automation.corejava.abstraction;

public class Developer extends Employee {

	@Override
	void showDetails() {
		System.out.println("Developer Show Details");
		
	}

}
