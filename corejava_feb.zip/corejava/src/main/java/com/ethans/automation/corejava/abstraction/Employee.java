package com.ethans.automation.corejava.abstraction;

public abstract class Employee {
	
	abstract void showDetails();

}
