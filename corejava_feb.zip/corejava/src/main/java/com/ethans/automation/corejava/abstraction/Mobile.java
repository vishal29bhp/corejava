package com.ethans.automation.corejava.abstraction;

public class Mobile extends Computer {
	
	public String hdd;
	public String ram;
	public String rom;
	public String network;
	
	public Mobile(String hdd,String ram,String rom, String network) {
		this.hdd = hdd;
		this.ram = ram;
		this.rom = rom;
		this.network=network;
	}

	@Override
	String getHDD() {
		return hdd;
	}

	@Override
	String getRAM() {
		return ram;
	}

	@Override
	String getROM() {
		return rom;
	}
	
	String getNetwork() {
		return network;
	}
	
	public String toString() {
		return getHDD() + "::" + getRAM() + "::" + getROM()+"::"+getNetwork();
	}

}
