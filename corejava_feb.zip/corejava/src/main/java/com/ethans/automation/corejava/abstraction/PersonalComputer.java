package com.ethans.automation.corejava.abstraction;

public class PersonalComputer extends Computer {
	
	public String hdd;
	public String ram;
	public String rom;
	
	public PersonalComputer(String hdd,String ram,String rom) {
		this.hdd = hdd;
		this.ram = ram;
		this.rom = rom;
	}

	@Override
	String getHDD() {
		return hdd;
	}

	@Override
	String getRAM() {
		return ram;
	}

	@Override
	String getROM() {
		return rom;
	}

}
