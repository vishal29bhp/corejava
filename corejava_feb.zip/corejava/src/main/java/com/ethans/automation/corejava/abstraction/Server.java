package com.ethans.automation.corejava.abstraction;

public class Server extends Computer {
	
	public String hdd;
	public String ram;
	public String rom;
	
	public Server(String hdd,String ram,String rom) {
		this.hdd = hdd;
		this.ram = ram;
		this.rom = rom;
	}

	@Override
	String getHDD() {
		return hdd;
	}

	@Override
	String getRAM() {
		return ram;
	}

	@Override
	String getROM() {
		return rom;
	}

}
