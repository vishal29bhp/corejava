package com.ethans.automation.corejava.abstraction.interfaces;

public class AxisBank implements Bank {

	@Override
	public String getPlRateOfInterest() {
		return "11.3";
	}

	@Override
	public String getHlRateOfInterest() {
		return "8.75";
	}

	@Override
	public String getCarLoanRateOfInterest() {
		return "12.10";
	}

	@Override
	public String getPaymentGateway() {
		return "VISA";
	}

}
