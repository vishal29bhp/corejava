package com.ethans.automation.corejava.abstraction.interfaces;

public interface Bank extends PaymentGateway{
	
	public String getPlRateOfInterest();
	public String getHlRateOfInterest();
	public String getCarLoanRateOfInterest();

}
