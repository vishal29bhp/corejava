package com.ethans.automation.corejava.abstraction.interfaces;

public class BankTest {

	public static void main(String[] args) {
		HdfcBank hdfc = new HdfcBank();
		Bank axis = new AxisBank();
		Bank yes = new YesBank();
		
		System.out.println("HDFC PL RATE: "+hdfc.getPlRateOfInterest());
		System.out.println("AXIS PL RATE: "+axis.getPlRateOfInterest());
		System.out.println("YES PL RATE: "+yes.getPlRateOfInterest());
		
		System.out.println("----------------------------------------");
		System.out.println("HDFC PAYMENT GATEWAY: "+hdfc.getPaymentGateway());
		System.out.println("AXIS PAYMENT GATEWAY: "+axis.getPaymentGateway());
		System.out.println("YES PAYMENT GATEWAY: "+yes.getPaymentGateway());
		
		System.out.println("----------------------------------------");
		System.out.println("HDFC CARD: "+hdfc.getCard());

	}

}
