package com.ethans.automation.corejava.abstraction.interfaces;

public abstract class Card {
	
	abstract public String getCard();

}
