package com.ethans.automation.corejava.abstraction.interfaces;

public class HdfcBank extends Card implements Bank {
		
	@Override
	public String getPlRateOfInterest() {
		return "11.5";
	}

	@Override
	public String getHlRateOfInterest() {
		return "8.25";
	}

	@Override
	public String getCarLoanRateOfInterest() {
		return "12.00";
	}

	@Override
	public String getPaymentGateway() {
		return "MasterCard";
	}
	
	@Override
	public String getCard() {
		return "CREDIT";
	}

}
