package com.ethans.automation.corejava.abstraction.interfaces;

public interface PaymentGateway {

	public String getPaymentGateway();
}
