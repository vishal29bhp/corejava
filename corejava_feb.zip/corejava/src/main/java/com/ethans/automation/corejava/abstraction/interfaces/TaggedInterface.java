package com.ethans.automation.corejava.abstraction.interfaces;

public class TaggedInterface implements Testable{
	
	public static void main(String[] args) {
		
		TaggedInterface ti = new TaggedInterface();
		ti.defaultMethod();
		Testable.defaultStaticMethod();
	}

}
