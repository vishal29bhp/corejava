package com.ethans.automation.corejava.abstraction.interfaces;

public interface Testable {
	
	default void defaultMethod() {
		System.out.println("Java 8 Default Method");
	}
	
    static void defaultStaticMethod() {
    	System.out.println("Java 8 Static Method");
	}

}
