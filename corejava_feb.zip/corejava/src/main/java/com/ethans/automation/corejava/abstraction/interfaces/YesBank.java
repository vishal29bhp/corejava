package com.ethans.automation.corejava.abstraction.interfaces;

public class YesBank implements Bank{
	
	
	@Override
	public String getPlRateOfInterest() {
		return "11.75";
	}

	@Override
	public String getHlRateOfInterest() {
		return "8.85";
	}

	@Override
	public String getCarLoanRateOfInterest() {
		return "13";
	}

	@Override
	public String getPaymentGateway() {
		return "AMEX";
	}

}
