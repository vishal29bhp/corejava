package com.ethans.automation.corejava.controlstat;

public class DoWhileTest {

	public static void main(String[] args) {

		int count = 10;
		
		do {
			
			System.out.println("Counting in Do While ,..." + count);
			//count++;

		} while (count < 10);
	}

}
