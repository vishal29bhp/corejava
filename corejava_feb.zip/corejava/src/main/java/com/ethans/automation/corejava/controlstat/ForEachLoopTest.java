package com.ethans.automation.corejava.controlstat;

public class ForEachLoopTest {

	public static void main(String[] args) {
		
		int array[] = {23,45,56,25,98};
		
		for(int value:array) {
			System.out.println("Using For Each Loop"+value);
		}
		
	}

}
