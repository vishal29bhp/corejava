package com.ethans.automation.corejava.controlstat;

public class ForTest {

	public static void main(String[] args) {
		
		for(int count=0;count<10;count++) {
			if (count == 5)
				break;
			
			System.out.println("Counting with for...."+count);
			
			
		}
		
		/*for(int count=10;count>0;count--) {
			System.out.println("Counting with for...."+count);
		}*/
	}

}
