package com.ethans.automation.corejava.controlstat;

public class IfTest {

	public static void main(String[] args) {

		int age = 12;

		if (age > 18) {
			System.out.println("you can live in India");
		    System.out.println("you can live in India");
		}
		
		else if (age <= 12) 
			System.out.println("you can live in India");
		
		else if (age >= 12.5) 
			System.out.println("you can live in India");
		
		else if (age > 100) 
			System.out.println("Go to Japan");
		
		else 
			System.out.println("you can also live in India");
		

	}

}
