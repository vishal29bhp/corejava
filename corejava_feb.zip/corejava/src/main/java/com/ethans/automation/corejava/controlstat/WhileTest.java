package com.ethans.automation.corejava.controlstat;

public class WhileTest {

	public static void main(String[] args) {

		int count = 0;
		
		while(count < 10) {
			System.out.println("Print this 10 time, Counting ..."+ count);
			count++;
		}
		
		System.out.println("Latest Count Value "+count);
	}

}
