package com.ethans.automation.corejava.operator;

public class UnaryOperatorTest {
	
	public static void main(String[] args) {
		
		int varX = 10;
		int varY = 10;
		
		int result = 0;
		
		System.out.println(varX++);//post increment
		System.out.println(++varX);//pre increment
		System.out.println(varX--);//post decrement
		System.out.println(--varX);//pre decrement
		
		
		result = varX++ + varY++;
		
		System.out.println(result); // 20 
		
		result = varX++ + varY--; // 11 , 11
		
		System.out.println(result); // 22 
		
		result = --varX + ++varY;// 12 , 10
		
		System.out.println(result); // 22
		
		
		System.out.println("Varx = "+ varX + "varY = "+varY);
		
		//10 12 12 10
		
		
	}

}
