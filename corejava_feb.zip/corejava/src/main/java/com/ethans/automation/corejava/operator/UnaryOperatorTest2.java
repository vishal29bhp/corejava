package com.ethans.automation.corejava.operator;

public class UnaryOperatorTest2 {
	
	public static void main(String[] args) {
		
		boolean isRight = false;
		boolean isWrong = true;
		
		System.out.println(!isRight);
		System.out.println(!isWrong);
		
		
		int var = -8;
		System.out.println(~var);
	}

}
