package com.ethans.automation.corejava.polymorphism;

public class FahterSonTest {

	public static void main(String[] args) {
		Father ft = new Father();
		ft.buildBankBalance();
		
		Father son = new Son();
		son.buildBankBalance();
		
		Father dt = new Dhoughter();
		dt.buildBankBalance();

	}

}
