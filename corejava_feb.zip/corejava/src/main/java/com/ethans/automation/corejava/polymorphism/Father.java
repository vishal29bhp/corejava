package com.ethans.automation.corejava.polymorphism;

public class Father {
	
	void buildBankBalance() {
		System.out.println("Bank Balance Through Job");
	}

}
