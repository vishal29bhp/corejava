package com.ethans.automation.corejava.polymorphism;

public class MethodOverloading {
	
	int add(int value1,long value2) {
		System.out.println("Integer Long Method Call");
		return (int) (value1+value2);
	}
	
	long add(long value1,int value2) {
		System.out.println("Long Int Method Call");
		return (value1+value2);
	}
	
	long add(long value1,long value2) {
		System.out.println("Long Method Call");
		return (value1+value2);
	}
	
	int add(int value1,int value2,int value3) {
		return value1+value2+value3;
	}
	
	String add(String value1,String value2) {
		return value1+value2;
	}
	
	float add(float value1,float value2) {
		return value1+value2;
	}
	
}
