package com.ethans.automation.corejava.polymorphism;

public class MethodOverloadingTest {

	public static void main(String[] args) {

		MethodOverloading mo = new MethodOverloading();
		System.out.println(mo.add(56L, 76L));
		System.out.println(mo.add(56, 76, 45));
		System.out.println(mo.add("Ethans ", "Tech"));
		System.out.println(mo.add(56.67f, 76.76f));
		main("Overloaded Main Method");
	}

	public static void main(String args) {
		
		System.out.println(args);
		MethodOverloading mo = new MethodOverloading();
		System.out.println(mo.add(56L, 76L));
		System.out.println(mo.add(56, 76, 45));
		System.out.println(mo.add("Ethans ", "Tech"));
		System.out.println(mo.add(56.67f, 76.76f));
	}
}
