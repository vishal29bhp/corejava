package com.ethans.automation.corejava.polymorphism;

public class Son extends Father {

	void buildBankBalance() {
		System.out.println("Bank Balance Through Playing");
	}
}
