package com.ethans.automation.corejava.thisusage;

public class Vehicle {

	String number;
	String type;
	String model;

	Vehicle() {
		
		number = "MH14DY5077";
		type = "SUV";
		model = "Car";
		//this.displayVehicle();
		this.displayVehicle2(this);
	}

	Vehicle(String type, String model) {
		this();
		this.type = type;
		this.model = model;
		//this.displayVehicle();
		this.displayVehicle2(this);
	}

	// 1. this usage as identifying instance variables
	Vehicle(String number, String type, String model) {
		this(type,model);
		//this.number = number;
		//this.type = type;
		//this.model = model;
		//this.displayVehicle();
		this.displayVehicle2(this);
		//this.displayVehicle2(new Vehicle());
	}
	
	Vehicle(String number){
		this.number = number;
		Vehicle2 vehicle2 = new Vehicle2(this);
	}
	
	void displayVehicle() {
		System.out.println(this.number+"::"+this.type+"::"+this.model);
	}
	
	void displayVehicle2(Vehicle vehicle) {
		System.out.println(vehicle.number+"::"+vehicle.type+"::"+vehicle.model);
	}
	
	Vehicle returnVehicle() {
		return this;
	}
	
	

}
