package com.ethans.automation.corejava.thisusage;

public class Vehicle2 {

	String number;
	String type;
	String model;
	String color;
	String chesisNumber;

	Vehicle2() {
		
		number = "MH14DY5077";
		type = "SUV";
		model = "Car";
		//this.displayVehicle();
		this.displayVehicle2(this);
	}

	Vehicle2(String type, String model) {
		this();
		this.type = type;
		this.model = model;
		//this.displayVehicle();
		this.displayVehicle2(this);
	}

	// 1. this usage as identifying instance variables
	Vehicle2(String number, String type, String model) {
		this(type,model);
		//this.number = number;
		//this.type = type;
		//this.model = model;
		//this.displayVehicle();
		this.displayVehicle2(this);
		//this.displayVehicle2(new Vehicle());
	}
	
	Vehicle2(Vehicle vehicle){
		this.number = vehicle.number;
		this.model = vehicle.model;
		this.type = vehicle.type;
		this.displayVehicle2(this);
	}
	
	void displayVehicle() {
		System.out.println(this.number+"::"+this.type+"::"+this.model);
	}
	
	void displayVehicle2(Vehicle2 vehicle) {
		System.out.println(vehicle.number+"::"+vehicle.type+"::"+vehicle.model);
	}
	
	

}
