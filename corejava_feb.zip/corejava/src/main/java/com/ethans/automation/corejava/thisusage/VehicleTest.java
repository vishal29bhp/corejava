package com.ethans.automation.corejava.thisusage;

public class VehicleTest {

	public static float main(String[] args) {
		
		//Vehicle car = new Vehicle();
		//car.displayVehicle();
		
		//Vehicle sedanCar = new Vehicle("MH12DY5353","LUV","SEDAN");
		//sedanCar.displayVehicle();
		
		Vehicle sedanCar = new Vehicle("MH12DY5353");
		
		Vehicle sedanCar2 = sedanCar.returnVehicle();
		return 0.0f;
		

	}

}
