package com.ethans.automation.corejava.variable;

public class A {
	

	public static void main(String[] args) {
		
		int a = 10 ;
		int b = 9;
		if ( a <= b && a >= b && a != b ) {
	        System.out.println("success");
	}
	}
}