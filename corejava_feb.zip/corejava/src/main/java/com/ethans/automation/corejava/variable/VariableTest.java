package com.ethans.automation.corejava.variable;

public class VariableTest {

	int instanceVar;

	static int instanceVar1;
	
	VariableTest(){
		
	}

	public static void main(String[] args) {

		int var = 10;
		System.out.println("First Local Var Value : " + var);
		System.out.println("First Static Var Value : " + VariableTest.instanceVar1);
		
		VariableTest vt = new VariableTest();
		vt.method();
		System.out.println(vt.instanceVar);
		

	}

	void method() {
		System.out.println("First Instance Var Value : " + instanceVar);
	}

}
