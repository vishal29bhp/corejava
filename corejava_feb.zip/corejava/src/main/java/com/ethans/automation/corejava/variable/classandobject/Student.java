package com.ethans.automation.corejava.variable.classandobject;

public class Student {

	// state or data or attributes
	int rollNo;
	String name;
	int age;
	float marks;
	String clazz;
	String division;
	static String college;

	Student() {
		rollNo = 1;
		name = "Vishal";
		clazz = "CoreJava";
		age = 38;
		division = "A";
		marks = 87.8f;
	}
	
	Student(float studentMarks, String studentClazz,
			String studDivision) {
		rollNo = 5;
		name = "Ankesh";
		clazz = studentClazz;// clazz = "CoreJava";
		age = 34;
		division = studDivision;
		marks = studentMarks;
	}

	Student(int rollNumber, String studentName, int studentAge, float studentMarks, String studentClazz,
			String studDivision) {
		rollNo = rollNumber;
		name = studentName;
		clazz = studentClazz;// clazz = "CoreJava";
		age = studentAge;
		division = studDivision;
		marks = studentMarks;
	}
	// Copy Constructor 
	Student(Student student) {
		rollNo = student.rollNo;
		name = student.name;
		clazz = student.clazz;// clazz = "CoreJava";
		age = student.age;
		division = student.division;
		marks = student.marks;
	}

	void displayStudent() {
		System.out.println("Student Details:::");
		System.out.println(rollNo + "::" + name + "::" + age + "::" + marks + "::" + clazz + "::" + division+ "::" + Student.college );
	}

	void defaultStudent() {
		rollNo = 1;
		name = "Vishal";
		clazz = "CoreJava";
		age = 38;
		division = "A";
		marks = 87.8f;
	}

	void initializeStudent(int rollNumber, String studentName, int studentAge, float studentMarks, String studentClazz,
			String studDivision) {
		rollNo = rollNumber;
		name = studentName;
		clazz = studentClazz;// clazz = "CoreJava";
		age = studentAge;
		division = studDivision;
		marks = studentMarks;
	}
	
	static void initializeCollege() {
		college="IIM";
	}
	
	static {
		college="IIM";
		System.out.println("This is Student Static Block");
	}
	
	{
		System.out.println("This is Student Block");
	}
}
