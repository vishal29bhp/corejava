package com.ethans.automation.corejava.variable.classandobject;

public class StudentTest {

	public static void main(String[] args) {
		
		//Student.initializeCollege();
		
		Student firstStudent = new Student();
		firstStudent.displayStudent();
		//firstStudent.defaultStudent();
		firstStudent.displayStudent();
		
		Student secondStudent = new Student();
		secondStudent.initializeStudent(2, "Amit", 34, 67.5f, "Core Java", "A");
		secondStudent.displayStudent();
		Student thirdStudent = new Student();
		thirdStudent.initializeStudent(3, "Prasad", 33, 87.5f, "Core Java", "A");
		thirdStudent.displayStudent();
		
		Student forthStudent = new Student(4, "Hanumant", 40, 75.5f, "German", "A");
		forthStudent.displayStudent();
		
		Student fifthStudent = new Student(54.5f, "Soap", "B");
		fifthStudent.displayStudent();
		
		Student sixthStudent = new Student(fifthStudent);
		sixthStudent.displayStudent();
		
		Student sevenStudent = sixthStudent;
		
	}

}
