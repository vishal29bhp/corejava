package com.ethans.automation.corejava.variable.inheritance;

public class AutomationTester extends Tester {
	
	

}
