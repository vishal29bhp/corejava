package com.ethans.automation.corejava.variable.inheritance;

public class Employee {

	String empName;
	String department;
	double salary;
	Address address;

	Employee() {

	}
	
	Employee(String empName, String department, double salary) {
		this.empName = empName;
		this.department = department;
		this.salary = salary;
	}
	

	Employee(String empName, String department, double salary, Address address) {
		this.empName = empName;
		this.department = department;
		this.salary = salary;
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

}
