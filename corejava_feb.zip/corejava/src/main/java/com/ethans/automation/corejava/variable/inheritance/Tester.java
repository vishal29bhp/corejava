package com.ethans.automation.corejava.variable.inheritance;

public class Tester extends Employee {
	
	double bonus;
	
	Tester(){
	
	}
	
}
