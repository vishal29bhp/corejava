package com.ethans.automation.corejava.variable.inheritance.supertest;

public class Address {

	String houseNo;
	String street;
	String city;
	String state;

	Address() {

	}

	Address(String houseNo, String street, String city, String state) {
		this.houseNo = houseNo;
		this.street = street;
		this.city = city;
		this.state = state;
	}

}
