package com.ethans.automation.corejava.variable.inheritance.supertest;

public class AutomationTester extends Tester {
	
	

}
