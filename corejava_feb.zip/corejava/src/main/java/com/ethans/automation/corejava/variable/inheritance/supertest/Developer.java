package com.ethans.automation.corejava.variable.inheritance.supertest;

public class Developer extends Employee {
	
	double bonus;
	double da;
	
	Developer(){
		
	}

}
