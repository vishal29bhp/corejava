package com.ethans.automation.corejava.variable.inheritance.supertest;

public class InheritanceTest {

	public static void main(String[] args) {
		
		Address address = new Address("A-101","Street1","Pune","MH");
				
		//Employee  emp = new Employee("Vishal","JAVA",5000,address);
		
		Employee  emp = new Employee("Vishal","JAVA",5000);
		emp.setAddress(address);
		
		Tester tester = new Tester();
		tester.initialTester();
		tester.printParentIntanceVariable();
		
		Tester tester1 = new Tester("Ethans","Java",25252.7,15151.8);
		
		
		
		

	}

}
