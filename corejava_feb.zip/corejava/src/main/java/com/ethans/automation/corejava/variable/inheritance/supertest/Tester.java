package com.ethans.automation.corejava.variable.inheritance.supertest;

public class Tester extends Employee {

	double bonus;
	

	Tester() {

	}

	Tester(String empName, String department, double salary, double bonus) {
		super(empName, department, salary);
		this.bonus = bonus;

	}

	void printParentIntanceVariable() {
		System.out.println(super.empName);
		System.out.println(super.department);
		System.out.println(super.salary);
		System.out.println(this.bonus);
	}

	void initialTester() {
		super.initializeEmployee();
		this.bonus = 262626.272;
	}
	
	

}
